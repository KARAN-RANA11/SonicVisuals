const generateForm = document.querySelector(".generate-form");
const generateBtn = generateForm.querySelector(".generate-btn");
const voiceBtn = generateForm.querySelector(".voice-btn");
const promptInput = generateForm.querySelector(".prompt-input");
const imageGallery = document.querySelector(".image-gallery");

const HUGGINGFACE_API_KEY = "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"; // Your Hugging Face API key here
let isImageGenerating = false;

const updateImageCard = (imgBlobArray) => {
  imgBlobArray.forEach((imgBlob, index) => {
    const imgCard = imageGallery.querySelectorAll(".img-card")[index];
    const imgElement = imgCard.querySelector("img");
    const downloadBtn = imgCard.querySelector(".download-btn");
    
    // Create a URL for the blob object
    const aiGeneratedImage = URL.createObjectURL(imgBlob);
    imgElement.src = aiGeneratedImage;
    
    // When the image is loaded, remove the loading class and set download attributes
    imgElement.onload = () => {
      imgCard.classList.remove("loading");
      downloadBtn.setAttribute("href", aiGeneratedImage);
      downloadBtn.setAttribute("download", `${new Date().getTime()}.jpg`);
    }
  });
}

const queryHuggingFaceAPI = async (data) => {
  const response = await fetch(
    "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0",
    {
      headers: { Authorization: `Bearer ${HUGGINGFACE_API_KEY}` },
      method: "POST",
      body: JSON.stringify(data),
    }
  );
  if (!response.ok) throw new Error("Failed to generate AI images. Make sure your API key is valid.");
  return response.blob();
};

const generateAiImages = async (userPrompt, userImgQuantity) => {
  try {
    const imgBlobArray = await Promise.all(
      Array.from({ length: userImgQuantity }, () => queryHuggingFaceAPI({ inputs: userPrompt }))
    );
    updateImageCard(imgBlobArray);
  } catch (error) {
    alert(error.message);
  } finally {
    generateBtn.removeAttribute("disabled");
    generateBtn.innerText = "Generate";
    isImageGenerating = false;
  }
}

const handleImageGeneration = (e) => {
  e.preventDefault();
  if (isImageGenerating) return;

  // Get user input and image quantity values
  const userPrompt = e.srcElement[0].value;
  const userImgQuantity = parseInt(e.srcElement[2].value);

  // Disable the generate button, update its text, and set the flag
  generateBtn.setAttribute("disabled", true);
  generateBtn.innerText = "Generating";
  isImageGenerating = true;

  // Creating HTML markup for image cards with loading state
  const imgCardMarkup = Array.from({ length: userImgQuantity }, () =>
    `<div class="img-card loading">
      <img src="images/loader.svg" alt="AI generated image">
      <a class="download-btn" href="#">
        <img src="images/download.svg" alt="download icon">
      </a>
    </div>`
  ).join("");

  imageGallery.innerHTML = imgCardMarkup;
  generateAiImages(userPrompt, userImgQuantity);
}

// Initialize Speech Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.continuous = false;
recognition.interimResults = false;
recognition.lang = 'en-US';

voiceBtn.addEventListener('click', () => {
  recognition.start();
});

recognition.onresult = (event) => {
  const speechToText = event.results[0][0].transcript;
  promptInput.value = speechToText;
};

recognition.onerror = (event) => {
  console.error(event.error);
};

generateForm.addEventListener("submit", handleImageGeneration);
